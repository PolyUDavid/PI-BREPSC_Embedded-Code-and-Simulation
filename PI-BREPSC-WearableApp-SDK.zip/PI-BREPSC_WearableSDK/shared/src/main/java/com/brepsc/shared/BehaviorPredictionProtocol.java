package com.brepsc.shared;

import android.util.Log;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

/**
 * 行人过马路行为预估信号协议
 * 基于PI-BREPSC仿真系统的RSU行为分析算法
 */
public class BehaviorPredictionProtocol {
    
    private static final String TAG = "BehaviorPrediction";
    
    // 行为预估数据包结构
    public static class BehaviorSignal {
        public String deviceId;              // 设备ID
        public long timestamp;               // 时间戳
        public float batteryLevel;           // 电量水平 (0.0-1.0)
        public int motionState;              // 运动状态: 0=静止长时间, 1=静止短时间, 2=移动
        public boolean buttonPressed;        // 是否按下过马路按钮
        public float[] accelerometer;        // 加速度计数据 [x,y,z]
        public int stationaryFrames;         // 静止帧数
        public float walkingConfidence;      // 步行置信度 (0.0-1.0)
        public int waitingAreaPosition;      // 等待区位置: 0=未知, 1=西侧, 2=东侧
        public boolean isAtWaitAreaEdge;     // 是否在等待区边缘
        public float intentProbability;      // 过马路意图概率 (0.0-1.0)
        
        public BehaviorSignal() {
            this.timestamp = System.currentTimeMillis();
            this.accelerometer = new float[3];
            this.motionState = 2; // 默认移动状态
            this.waitingAreaPosition = 0; // 默认未知位置
        }
        
        /**
         * 将行为信号编码为BLE广播数据包
         * 遵循PI-BREPSC仿真系统的数据格式
         */
        public byte[] encodeToBLEPacket() {
            byte[] packet = new byte[31]; // BLE广播包最大31字节
            int index = 0;
            
            // 设备ID (4字节)
            byte[] idBytes = deviceId.getBytes();
            System.arraycopy(idBytes, 0, packet, index, Math.min(4, idBytes.length));
            index += 4;
            
            // 时间戳 (4字节，取低32位)
            int ts = (int)(timestamp & 0xFFFFFFFF);
            packet[index++] = (byte)(ts >> 24);
            packet[index++] = (byte)(ts >> 16);
            packet[index++] = (byte)(ts >> 8);
            packet[index++] = (byte)(ts);
            
            // 电量水平 (1字节，0-255)
            packet[index++] = (byte)(batteryLevel * 255);
            
            // 运动状态 (1字节)
            packet[index++] = (byte)motionState;
            
            // 按钮状态 (1字节)
            packet[index++] = (byte)(buttonPressed ? 1 : 0);
            
            // 加速度计数据 (6字节，每轴2字节)
            for (int i = 0; i < 3; i++) {
                short accel = (short)(accelerometer[i] * 1000); // 转换为毫g
                packet[index++] = (byte)(accel >> 8);
                packet[index++] = (byte)(accel);
            }
            
            // 静止帧数 (2字节)
            packet[index++] = (byte)(stationaryFrames >> 8);
            packet[index++] = (byte)(stationaryFrames);
            
            // 步行置信度 (1字节)
            packet[index++] = (byte)(walkingConfidence * 255);
            
            // 等待区位置 (1字节)
            packet[index++] = (byte)waitingAreaPosition;
            
            // 是否在等待区边缘 (1字节)
            packet[index++] = (byte)(isAtWaitAreaEdge ? 1 : 0);
            
            // 意图概率 (1字节)
            packet[index++] = (byte)(intentProbability * 255);
            
            // 校验和 (1字节)
            byte checksum = 0;
            for (int i = 0; i < index; i++) {
                checksum ^= packet[i];
            }
            packet[index++] = checksum;
            
            // 填充剩余字节
            while (index < 31) {
                packet[index++] = 0;
            }
            
            return packet;
        }
    }
    
    /**
     * 行为分析器 - 基于仿真系统的算法
     */
    public static class BehaviorAnalyzer {
        
        private static final int STATIONARY_FRAMES_SHORT = 30;  // 0.5秒 @ 60FPS
        private static final int STATIONARY_FRAMES_LONG = 120;  // 2秒 @ 60FPS
        private static final float MOVEMENT_THRESHOLD = 0.5f;   // 运动检测阈值
        
        private float[] lastAccelData = new float[3];
        private int stationaryCounter = 0;
        private boolean isMoving = false;
        
        /**
         * 分析加速度计数据，返回运动状态
         * @param accelData [x, y, z] 加速度数据
         * @return 0=长时间静止, 1=短时间静止, 2=移动
         */
        public int analyzeMotionState(float[] accelData) {
            if (accelData == null || accelData.length != 3) {
                return 2; // 默认移动状态
            }
            
            // 计算运动变化量
            float movement = 0;
            for (int i = 0; i < 3; i++) {
                movement += Math.abs(accelData[i] - lastAccelData[i]);
            }
            
            // 更新上次数据
            System.arraycopy(accelData, 0, lastAccelData, 0, 3);
            
            if (movement < MOVEMENT_THRESHOLD) {
                stationaryCounter++;
                isMoving = false;
            } else {
                stationaryCounter = 0;
                isMoving = true;
                return 2; // 移动状态
            }
            
            // 静止状态判断
            if (stationaryCounter >= STATIONARY_FRAMES_LONG) {
                return 0; // 长时间静止
            } else if (stationaryCounter >= STATIONARY_FRAMES_SHORT) {
                return 1; // 短时间静止
            } else {
                return 2; // 移动状态
            }
        }
        
        /**
         * 计算步行置信度
         */
        public float calculateWalkingConfidence(float[] accelData, int motionState) {
            if (motionState == 2) { // 移动状态
                // 简单的步行模式检测
                float magnitude = (float)Math.sqrt(
                    accelData[0] * accelData[0] + 
                    accelData[1] * accelData[1] + 
                    accelData[2] * accelData[2]
                );
                
                // 正常步行的加速度幅值约在8-12 m/s²范围
                if (magnitude >= 8.0f && magnitude <= 15.0f) {
                    return Math.min(1.0f, magnitude / 12.0f);
                }
            }
            return motionState == 2 ? 0.3f : 0.0f;
        }
        
        /**
         * 基于多因素计算过马路意图概率
         * 参考仿真系统的意图计算算法
         */
        public float calculateCrossingIntent(BehaviorSignal signal) {
            float intentProb = 0.0f;
            
            // 基础概率：按钮按下
            if (signal.buttonPressed) {
                intentProb += 0.6f; // 按钮按下强烈表示意图
            }
            
            // 位置因素：在等待区边缘
            if (signal.isAtWaitAreaEdge) {
                intentProb += 0.3f;
            } else if (signal.waitingAreaPosition > 0) {
                intentProb += 0.1f; // 在等待区内
            }
            
            // 运动状态因素
            switch (signal.motionState) {
                case 0: // 长时间静止
                    intentProb += 0.2f; // 等待信号
                    break;
                case 1: // 短时间静止
                    intentProb += 0.1f; // 可能在观察
                    break;
                case 2: // 移动
                    if (signal.walkingConfidence > 0.7f) {
                        intentProb += 0.15f; // 高置信度步行
                    }
                    break;
            }
            
            // 设备状态因素
            if (signal.batteryLevel > 0.2f) {
                intentProb += 0.05f; // 设备正常工作
            }
            
            // 时间持续性因素（静止时间越长，意图越明确）
            if (signal.stationaryFrames > STATIONARY_FRAMES_LONG) {
                float timeBonus = Math.min(0.2f, 
                    (signal.stationaryFrames - STATIONARY_FRAMES_LONG) / 300.0f);
                intentProb += timeBonus;
            }
            
            return Math.min(1.0f, Math.max(0.0f, intentProb));
        }
    }
    
    /**
     * RSU信号发送器
     */
    public static class RSUSignalSender {
        
        private BehaviorAnalyzer analyzer = new BehaviorAnalyzer();
        private long lastSendTime = 0;
        private static final long SEND_INTERVAL = 500; // 500ms发送间隔
        
        /**
         * 构建并发送行为预估信号给RSU
         */
        public BehaviorSignal buildBehaviorSignal(
                String deviceId,
                float batteryLevel,
                float[] accelerometer,
                boolean buttonPressed,
                int waitingAreaPosition,
                boolean isAtWaitAreaEdge) {
            
            BehaviorSignal signal = new BehaviorSignal();
            signal.deviceId = deviceId;
            signal.batteryLevel = batteryLevel;
            signal.buttonPressed = buttonPressed;
            signal.waitingAreaPosition = waitingAreaPosition;
            signal.isAtWaitAreaEdge = isAtWaitAreaEdge;
            
            // 复制加速度计数据
            if (accelerometer != null && accelerometer.length >= 3) {
                System.arraycopy(accelerometer, 0, signal.accelerometer, 0, 3);
            }
            
            // 分析运动状态
            signal.motionState = analyzer.analyzeMotionState(signal.accelerometer);
            signal.stationaryFrames = analyzer.stationaryCounter;
            
            // 计算步行置信度
            signal.walkingConfidence = analyzer.calculateWalkingConfidence(
                signal.accelerometer, signal.motionState);
            
            // 计算过马路意图概率
            signal.intentProbability = analyzer.calculateCrossingIntent(signal);
            
            Log.d(TAG, String.format(
                "行为信号: 设备=%s, 运动=%d, 按钮=%b, 位置=%d, 边缘=%b, 意图=%.2f",
                deviceId, signal.motionState, buttonPressed, 
                waitingAreaPosition, isAtWaitAreaEdge, signal.intentProbability));
            
            return signal;
        }
        
        /**
         * 检查是否应该发送信号（限制发送频率）
         */
        public boolean shouldSendSignal() {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastSendTime >= SEND_INTERVAL) {
                lastSendTime = currentTime;
                return true;
            }
            return false;
        }
    }
} 