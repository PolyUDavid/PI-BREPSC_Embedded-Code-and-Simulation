package com.brepsc.wearable;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseCallback;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ProgressBar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.brepsc.shared.BehaviorPredictionProtocol;

/**
 * PI-BREPSC 手环主活动
 * 集成行为预估和RSU通信功能
 */
public class WearMainActivity extends Activity implements SensorEventListener, LocationListener {
    
    private static final String TAG = "WearMainActivity";
    private static final int PERMISSION_REQUEST_CODE = 1001;
    
    // UI组件
    private Button btnCrossRequest;
    private Button btnBleStatus;
    private Button btnSafetyMonitor;
    private Button btnSettings;
    private TextView tvStatus;
    private TextView tvIntent;
    private TextView tvRSSI;
    private ProgressBar pbBattery;
    
    // 传感器和位置
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private LocationManager locationManager;
    private float[] accelData = new float[3];
    private boolean isAtWaitArea = false;
    private boolean isAtWaitAreaEdge = false;
    private int waitingAreaPosition = 0; // 0=未知, 1=西侧, 2=东侧
    
    // 蓝牙和通信
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothLeAdvertiser advertiser;
    private BehaviorPredictionProtocol.RSUSignalSender signalSender;
    
    // 状态变量
    private boolean buttonPressed = false;
    private float batteryLevel = 1.0f;
    private String deviceId;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean isAdvertising = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wear_main);
        
        initializeViews();
        initializeDeviceId();
        initializeSensors();
        initializeBluetooth();
        initializeSignalSender();
        
        requestPermissions();
        startPeriodicUpdates();
    }
    
    private void initializeViews() {
        // 4个主要按钮
        btnCrossRequest = findViewById(R.id.btn_cross_request);
        btnBleStatus = findViewById(R.id.btn_ble_status);
        btnSafetyMonitor = findViewById(R.id.btn_safety_monitor);
        btnSettings = findViewById(R.id.btn_settings);
        
        // 状态显示
        tvStatus = findViewById(R.id.tv_status);
        tvIntent = findViewById(R.id.tv_intent);
        tvRSSI = findViewById(R.id.tv_rssi);
        pbBattery = findViewById(R.id.pb_battery);
        
        // 设置按钮点击事件
        btnCrossRequest.setOnClickListener(this::onCrossRequestClick);
        btnBleStatus.setOnClickListener(this::onBleStatusClick);
        btnSafetyMonitor.setOnClickListener(this::onSafetyMonitorClick);
        btnSettings.setOnClickListener(this::onSettingsClick);
    }
    
    private void initializeDeviceId() {
        // 生成唯一设备ID，基于设备信息
        deviceId = "W" + android.os.Build.SERIAL.substring(0, Math.min(3, android.os.Build.SERIAL.length()));
        Log.d(TAG, "设备ID: " + deviceId);
    }
    
    private void initializeSensors() {
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        
        if (accelerometer == null) {
            Log.w(TAG, "设备没有加速度计");
            tvStatus.setText("传感器不可用");
        }
    }
    
    private void initializeBluetooth() {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Log.e(TAG, "设备不支持蓝牙");
            tvStatus.setText("蓝牙不可用");
            return;
        }
        
        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivity(enableBtIntent);
        }
        
        advertiser = bluetoothAdapter.getBluetoothLeAdvertiser();
        if (advertiser == null) {
            Log.e(TAG, "设备不支持BLE广播");
        }
    }
    
    private void initializeSignalSender() {
        signalSender = new BehaviorPredictionProtocol.RSUSignalSender();
    }
    
    private void requestPermissions() {
        String[] permissions = {
            android.Manifest.permission.BLUETOOTH,
            android.Manifest.permission.BLUETOOTH_ADMIN,
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION
        };
        
        boolean allGranted = true;
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allGranted = false;
                break;
            }
        }
        
        if (!allGranted) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        }
    }
    
    /**
     * 1. 智能过马路按钮
     */
    private void onCrossRequestClick(View view) {
        buttonPressed = !buttonPressed;
        
        if (buttonPressed) {
            btnCrossRequest.setText("取消过马路");
            btnCrossRequest.setBackgroundColor(getColor(android.R.color.holo_red_dark));
            tvStatus.setText("已发送过马路请求");
            
            // 立即发送高优先级信号
            sendBehaviorSignalToRSU();
            
        } else {
            btnCrossRequest.setText("🚦 过马路请求");
            btnCrossRequest.setBackgroundColor(getColor(android.R.color.holo_green_dark));
            tvStatus.setText("已取消过马路请求");
        }
        
        Log.d(TAG, "过马路按钮状态: " + buttonPressed);
    }
    
    /**
     * 2. 蓝牙信号状态按钮
     */
    private void onBleStatusClick(View view) {
        if (isAdvertising) {
            stopBLEAdvertising();
            btnBleStatus.setText("📱 启动蓝牙");
            btnBleStatus.setBackgroundColor(getColor(android.R.color.darker_gray));
            tvRSSI.setText("蓝牙已断开");
        } else {
            startBLEAdvertising();
            btnBleStatus.setText("📱 停止蓝牙");
            btnBleStatus.setBackgroundColor(getColor(android.R.color.holo_blue_dark));
            tvRSSI.setText("正在连接RSU...");
        }
    }
    
    /**
     * 3. 安全状态监控按钮
     */
    private void onSafetyMonitorClick(View view) {
        // 切换安全监控显示模式
        if (tvIntent.getVisibility() == View.VISIBLE) {
            tvIntent.setVisibility(View.GONE);
            btnSafetyMonitor.setText("🔍 显示安全状态");
        } else {
            tvIntent.setVisibility(View.VISIBLE);
            btnSafetyMonitor.setText("🔍 隐藏安全状态");
            updateSafetyStatus();
        }
    }
    
    /**
     * 4. 设备设置按钮
     */
    private void onSettingsClick(View view) {
        // 这里可以打开设置界面或显示设置选项
        Intent settingsIntent = new Intent(this, WearSettingsActivity.class);
        startActivity(settingsIntent);
    }
    
    /**
     * 开始BLE广播
     */
    private void startBLEAdvertising() {
        if (advertiser == null) {
            Log.e(TAG, "BLE广播器不可用");
            return;
        }
        
        AdvertiseSettings settings = new AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .setConnectable(false)
            .build();
        
        AdvertiseData data = new AdvertiseData.Builder()
            .setIncludeDeviceName(true)
            .setIncludeTxPowerLevel(true)
            .addManufacturerData(0x004C, deviceId.getBytes()) // 使用Apple公司ID作为示例
            .build();
        
        try {
            advertiser.startAdvertising(settings, data, advertiseCallback);
            isAdvertising = true;
            Log.d(TAG, "开始BLE广播");
        } catch (SecurityException e) {
            Log.e(TAG, "权限不足，无法开始BLE广播", e);
        }
    }
    
    /**
     * 停止BLE广播
     */
    private void stopBLEAdvertising() {
        if (advertiser != null && isAdvertising) {
            try {
                advertiser.stopAdvertising(advertiseCallback);
                isAdvertising = false;
                Log.d(TAG, "停止BLE广播");
            } catch (SecurityException e) {
                Log.e(TAG, "权限不足，无法停止BLE广播", e);
            }
        }
    }
    
    /**
     * BLE广播回调
     */
    private AdvertiseCallback advertiseCallback = new AdvertiseCallback() {
        @Override
        public void onStartSuccess(AdvertiseSettings settingsInEffect) {
            super.onStartSuccess(settingsInEffect);
            Log.d(TAG, "BLE广播启动成功");
            runOnUiThread(() -> tvRSSI.setText("RSU连接成功"));
        }
        
        @Override
        public void onStartFailure(int errorCode) {
            super.onStartFailure(errorCode);
            Log.e(TAG, "BLE广播启动失败: " + errorCode);
            runOnUiThread(() -> tvRSSI.setText("RSU连接失败"));
            isAdvertising = false;
        }
    };
    
    /**
     * 发送行为预估信号给RSU
     */
    private void sendBehaviorSignalToRSU() {
        if (!signalSender.shouldSendSignal()) {
            return; // 频率限制
        }
        
        // 构建行为信号
        BehaviorPredictionProtocol.BehaviorSignal signal = signalSender.buildBehaviorSignal(
            deviceId,
            batteryLevel,
            accelData,
            buttonPressed,
            waitingAreaPosition,
            isAtWaitAreaEdge
        );
        
        // 编码为BLE数据包
        byte[] packet = signal.encodeToBLEPacket();
        
        // 通过BLE广播发送（这里简化处理，实际可能需要更复杂的通信协议）
        if (isAdvertising) {
            Log.d(TAG, String.format("发送给RSU: 意图概率=%.2f, 运动状态=%d", 
                signal.intentProbability, signal.motionState));
            
            // 更新UI显示
            runOnUiThread(() -> {
                tvIntent.setText(String.format("过马路意图: %.0f%%", signal.intentProbability * 100));
                updateMotionStateUI(signal.motionState);
            });
        }
    }
    
    /**
     * 更新运动状态UI
     */
    private void updateMotionStateUI(int motionState) {
        String stateText;
        int stateColor;
        
        switch (motionState) {
            case 0:
                stateText = "长时间静止";
                stateColor = android.R.color.holo_orange_dark;
                break;
            case 1:
                stateText = "短时间静止";
                stateColor = android.R.color.holo_blue_light;
                break;
            case 2:
            default:
                stateText = "正在移动";
                stateColor = android.R.color.holo_green_light;
                break;
        }
        
        tvStatus.setText("运动状态: " + stateText);
        tvStatus.setTextColor(getColor(stateColor));
    }
    
    /**
     * 更新安全状态显示
     */
    private void updateSafetyStatus() {
        // 这里可以添加更复杂的安全状态计算
        String safetyStatus = String.format(
            "设备ID: %s\n电量: %.0f%%\n位置: %s\n边缘状态: %s",
            deviceId,
            batteryLevel * 100,
            getWaitAreaText(waitingAreaPosition),
            isAtWaitAreaEdge ? "在等待区边缘" : "在等待区内"
        );
        
        tvIntent.setText(safetyStatus);
    }
    
    private String getWaitAreaText(int position) {
        switch (position) {
            case 1: return "西侧等待区";
            case 2: return "东侧等待区";
            default: return "位置未知";
        }
    }
    
    /**
     * 定期更新
     */
    private void startPeriodicUpdates() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                updateBatteryLevel();
                sendBehaviorSignalToRSU();
                handler.postDelayed(this, 1000); // 每秒更新
            }
        }, 1000);
    }
    
    /**
     * 更新电池电量
     */
    private void updateBatteryLevel() {
        BatteryManager batteryManager = (BatteryManager) getSystemService(Context.BATTERY_SERVICE);
        if (batteryManager != null) {
            int level = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            batteryLevel = level / 100.0f;
            pbBattery.setProgress(level);
        }
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
        }
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopBLEAdvertising();
        handler.removeCallbacksAndMessages(null);
    }
    
    // 传感器事件监听
    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            System.arraycopy(event.values, 0, accelData, 0, 3);
        }
    }
    
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // 传感器精度变化处理
    }
    
    // 位置监听器（简化实现）
    @Override
    public void onLocationChanged(Location location) {
        // 根据位置判断等待区位置（这里需要根据实际RSU位置进行配置）
        // 简化逻辑，实际应该基于GPS坐标和已知的交通路口位置
        waitingAreaPosition = 1; // 默认西侧
        isAtWaitAreaEdge = true; // 简化设置
    }
    
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {}
    
    @Override
    public void onProviderEnabled(String provider) {}
    
    @Override
    public void onProviderDisabled(String provider) {}
} 