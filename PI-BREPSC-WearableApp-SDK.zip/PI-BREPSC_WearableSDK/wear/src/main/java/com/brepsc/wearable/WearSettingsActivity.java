package com.brepsc.wearable;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

/**
 * 手表设置活动
 */
public class WearSettingsActivity extends Activity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        TextView textView = new TextView(this);
        textView.setText("PI-BREPSC 手环设置\n\n功能开发中...");
        textView.setTextColor(0xFFFFFFFF);
        textView.setBackgroundColor(0xFF202020);
        textView.setPadding(32, 32, 32, 32);
        textView.setTextSize(16);
        
        setContentView(textView);
    }
} 