#!/bin/bash

# PI-BREPSC 可穿戴APP SDK 构建脚本
# 生成可安装的APK文件

echo "🚀 开始构建PI-BREPSC可穿戴APP..."

# 检查环境
if ! command -v ./gradlew &> /dev/null; then
    echo "❌ Gradle Wrapper 未找到，请确保在正确的项目目录中"
    exit 1
fi

# 清理之前的构建
echo "🧹 清理之前的构建文件..."
./gradlew clean

# 构建共享模块
echo "📚 构建共享模块..."
./gradlew :shared:build

# 构建手表应用
echo "⌚ 构建手表应用..."
./gradlew :wear:assembleRelease

# 构建手机应用（如果存在）
echo "📱 构建手机应用..."
if [ -d "app" ]; then
    ./gradlew :app:assembleRelease
fi

# 检查构建结果
WEAR_APK="wear/build/outputs/apk/release/wear-release.apk"
APP_APK="app/build/outputs/apk/release/app-release.apk"

if [ -f "$WEAR_APK" ]; then
    echo "✅ 手表应用构建成功: $WEAR_APK"
    
    # 复制到项目根目录并重命名
    cp "$WEAR_APK" "./PI-BREPSC-WearableApp.apk"
    echo "📦 APK文件已复制到: PI-BREPSC-WearableApp.apk"
    
    # 显示APK信息
    echo ""
    echo "📊 APK信息:"
    ls -lh PI-BREPSC-WearableApp.apk
    
    # 如果安装了aapt，显示更多信息
    if command -v aapt &> /dev/null; then
        echo ""
        echo "📋 应用详情:"
        aapt dump badging PI-BREPSC-WearableApp.apk | grep -E "(package:|application-label:|uses-permission:|uses-feature:)"
    fi
    
else
    echo "❌ 手表应用构建失败"
    exit 1
fi

if [ -f "$APP_APK" ]; then
    echo "✅ 手机应用构建成功: $APP_APK"
    cp "$APP_APK" "./PI-BREPSC-PhoneApp.apk"
    echo "📦 手机APK已复制到: PI-BREPSC-PhoneApp.apk"
fi

echo ""
echo "🎉 构建完成！"
echo ""
echo "📁 生成的文件："
echo "   - PI-BREPSC-WearableApp.apk (手环/手表应用)"
if [ -f "PI-BREPSC-PhoneApp.apk" ]; then
    echo "   - PI-BREPSC-PhoneApp.apk (手机应用)"
fi
echo ""
echo "📱 安装方法："
echo "   1. 手机安装: adb install PI-BREPSC-WearableApp.apk"
echo "   2. 或直接发送APK文件到目标设备进行安装"
echo ""
echo "⚠️  注意事项："
echo "   - 需要在设备设置中启用'未知来源'应用安装"
echo "   - 手表版本会自动同步到已配对的手表设备"
echo "   - 首次运行需要授予蓝牙和位置权限"
echo ""
echo "🔧 基于PI-BREPSC仿真系统的手环功能："
echo "   ✓ 智能过马路请求 (🚦)"
echo "   ✓ 蓝牙RSU通信 (📱)"  
echo "   ✓ 行为安全监控 (🔍)"
echo "   ✓ 设备管理设置 (⚙️)"
echo "   ✓ 实时行为预估信号发送"
echo "" 