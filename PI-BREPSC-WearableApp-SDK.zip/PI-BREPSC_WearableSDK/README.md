# PI-BREPSC 手环APP SDK

## 项目概述

基于PI-BREPSC仿真系统中的手环功能模块开发的智能手环APP，支持Android手机和智能手表。专注于行人过马路安全和智能交通信号控制。

## 核心手环功能 (4个主要按钮)

### 1. 🚦 智能过马路按钮
- 一键发送过马路请求到RSU(路边单元)
- 自动检测等待区位置
- 发送BLE信号给交通信号系统

### 2. 📱 蓝牙信号状态
- 实时显示与RSU的BLE连接状态
- 信号强度指示器 (RSSI)
- 设备电量显示
- 自动重连功能

### 3. 🔍 安全状态监控
- 实时行人运动状态检测
- 异常行为预警
- 意图概率显示
- 等待时间计时器

### 4. ⚙️ 设备设置
- 蓝牙发射功率调节
- 设备ID配置
- 省电模式切换
- 连接偏好设置

## 技术特性

### 手环核心功能
- **BLE 4.0+通信**: 与RSU进行低功耗蓝牙通信
- **RSSI信号监控**: 实时信号强度检测和报告
- **运动状态检测**: 静止/移动/长时间静止状态识别  
- **按钮请求功能**: 模拟仿真系统中的按钮按下功能
- **设备状态管理**: 电量监控、信号质量管理
- **意图识别**: 基于位置和行为的过马路意图检测

### 兼容性
- Android手机 (API 24+)
- Wear OS智能手表 (API 28+)
- 支持多种智能手环设备

## 文件结构

```
PI-BREPSC_WearableSDK/
├── app/                           # 手机APP
│   ├── src/main/java/com/brepsc/wearable/
│   │   ├── MainActivity.java      # 主界面
│   │   ├── BluetoothService.java  # 蓝牙服务
│   │   ├── RSUCommunicator.java   # RSU通信模块
│   │   └── DeviceStatusManager.java # 设备状态管理
├── wear/                          # 手表APP
│   ├── src/main/java/com/brepsc/wearable/
│   │   ├── WearMainActivity.java  # 手表主界面
│   │   ├── CrossingButton.java    # 过马路按钮
│   │   ├── StatusMonitor.java     # 状态监控
│   │   └── WearBleManager.java    # 手表蓝牙管理
├── shared/                        # 共享模块
│   └── src/main/java/com/brepsc/shared/
│       ├── PedestrianData.java    # 行人数据模型
│       ├── BLEProtocol.java       # BLE通信协议
│       └── ConfigConstants.java   # 配置常量
└── PI-BREPSC-WearableApp.apk     # 可安装的APK包
```

## 基于仿真系统的功能映射

| 仿真系统功能 | 手环APP实现 |
|-------------|------------|
| `has_wearable_device` | BLE设备初始化和配置 |
| `device_battery_level` | 实时电量监控和显示 |
| `device_signal_strength` | RSSI信号强度检测 |
| `is_requesting_button_press` | 智能过马路按钮功能 |
| `motion_state` | 运动状态检测(移动/静止) |
| `ble_tx_power` | BLE发射功率管理 |
| RSU扫描检测 | 自动RSU发现和连接 |
| 意图概率计算 | 基于行为的意图显示 |

## 快速安装

1. 下载 `PI-BREPSC-WearableApp.apk`
2. 安装到手机，自动同步到配对手表
3. 开启蓝牙和位置权限
4. 启动APP开始使用

## 使用场景

- 智能交通路口行人过马路
- 与PI-BREPSC仿真系统实时交互
- 行人安全监控和预警
- 交通信号优化数据收集

## 技术规格

- **最低SDK版本**: Android API 24 (Android 7.0)
- **目标SDK版本**: Android API 34 (Android 14)
- **Wear OS**: API 28+
- **权限需求**: 蓝牙、位置、网络访问
- **存储需求**: < 10MB

## 开发团队

基于PI-BREPSC仿真平台 © 2024 